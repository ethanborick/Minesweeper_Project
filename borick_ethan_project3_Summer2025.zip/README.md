Name: Ethan Borick
Section: 15182
UFL email: eborick@ufl.edu
System: mac
Compiler: clang++
SFML version: 2.5
IDE: CLion
Other notes: None